$(document).ready(function() {
    $('.nav-toggle').click(
        function() {
            $('.menu').slideToggle(200);
        }
    )

});